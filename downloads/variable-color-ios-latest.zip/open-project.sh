#!/bin/bash
open "variable-color-framework-demo.xcworkspace"
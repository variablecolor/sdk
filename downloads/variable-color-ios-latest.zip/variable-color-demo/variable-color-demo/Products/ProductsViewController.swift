//
//  ProductsViewController.swift
//  variable-color-demo
//
//  Created by Andrew T on 5/2/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit
import VariableColor

class ProductsViewController: UIViewController, VCFProductDownloaderDelegate {
    @IBOutlet var btnBrowseProducts: UIButton!
    @IBOutlet var btnSearch: UIButton!
    @IBOutlet var productStatusLabel: UILabel!
    @IBOutlet var productStatus2Label: UILabel!

    let spinner = LabeledSpinner(effect: UIBlurEffect(style: .dark))

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(spinner)

        btnBrowseProducts.isEnabled = false
        updateProductStatusLabels()
    }

    func updateProductStatusLabels() {
        updateDownloadNeededLabel()
        updateProductCountLabel()
    }

    func updateDownloadNeededLabel() {
        VCFCentral.productManager.checkIfProductDownloadRequired { isRequired, err in
            self.productStatus2Label.text = ""

            guard err == nil else {
                self.productStatus2Label.text = "error checking download status"
                return
            }

            if isRequired {
                self.productStatus2Label.text = "download / resync required"
            } else {
                self.productStatus2Label.text = "download / resync not required"
            }
        }
    }

    func updateProductCountLabel() {
        productStatusLabel.text = ""

        VCFCentral.productManager.countDownloadedProducts { count, _ in
            self.productStatusLabel.text = "\(count) products loaded"

            if count.intValue > 0 {
                self.btnBrowseProducts.isEnabled = true
            } else {
                self.btnBrowseProducts.isEnabled = false
            }
        }
    }

    @IBAction func btnDownloadProdsPressed(_: Any) {
        productStatusLabel.text = "downloading..."

        spinner.showWith(title: "Downloading")

        VCFCentral.productManager.downloadProducts(with: self)
    }

    func productDownloaderDidUpdateProgress(_ progress: Float) {
        productStatusLabel.text = String(format: "%0.0f%% complete", progress * 100)
    }

    func productDownloaderDidComplete() {
        spinner.hide()
        let title = "Download Complete"
        let msg = ""

        let ac = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true, completion: nil)

        updateProductStatusLabels()
    }

    func productDownloaderDidFailWithError(_: Error!) {
        updateProductStatusLabels()
    }
}

//
//  FiltersViewController.swift
//  variable-color-demo
//
//  Created by Wade Gasior on 5/3/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit
import VariableColor

protocol FilterChooserProtocol {
    // filterMode is either products or inspirations
    func filtersSelected(filters: VCFProductFilterSet, filterMode: String)
}

class FiltersViewController: UIViewController {
    public var filters: VCFProductFilterSet?
    public var filterChooserDelegate: FilterChooserProtocol?
    @IBOutlet var filtersTableView: UITableView!
    @IBOutlet var productsInspirationsToggleButton: UIButton!

    public var filterMode = "products"

    override func viewDidLoad() {
        super.viewDidLoad()

        refreshFilters()
        refreshProductsInspirationsButton()
    }

    @IBAction func handleReset(_: Any) {
        if filterMode == "products" {
            VCFProductSearch.fetchProductFilters { filters, _ in
                self.filters = filters
                self.filtersTableView.reloadData()
            }
        } else {
            VCFProductSearch.fetchInspirationFilters { filters, _ in
                self.filters = filters
                self.filtersTableView.reloadData()
            }
        }
    }

    func refreshFilters() {
        guard filters == nil else {
            return
        }

        if filterMode == "products" {
            VCFProductSearch.fetchProductFilters { filters, _ in
                self.filters = filters
                self.filtersTableView.reloadData()
            }
        } else {
            VCFProductSearch.fetchInspirationFilters { filters, _ in
                self.filters = filters
                self.filtersTableView.reloadData()
            }
        }
    }

    @IBAction func handleApply(_: Any) {
        filterChooserDelegate?.filtersSelected(filters: filters!, filterMode: filterMode)
        navigationController?.popViewController(animated: true)
    }

    func refreshProductsInspirationsButton() {
        productsInspirationsToggleButton.setTitle(filterMode, for: .normal)
    }

    @IBAction func handleProductsInspirationsToggle(_: Any) {
        if filterMode == "products" {
            filterMode = "inspirations"
        } else {
            filterMode = "products"
        }

        refreshProductsInspirationsButton()
        handleReset("")
    }
}

extension FiltersViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in _: UITableView) -> Int {
        guard filters != nil else {
            return 0
        }

        return filters!.availableFiltersKeyCount()
    }

    func tableView(_: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard filters != nil else {
            return 0
        }

        return filters!.availableFiltersValCountForKey(at: section)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "filter-val-cell", for: indexPath)

        let filterKV = filters!.availableFilter(at: indexPath)
        cell.textLabel?.text = filterKV.val

        if filters!.filterIsSelected(filterKV) {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }

        return cell
    }

    func tableView(_: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        let filterKV = filters!.availableFilter(at: indexPath)

        filters!.toggleFilter(filterKV) { _, _ in
            self.filtersTableView.reloadData()
        }
    }

    func tableView(_: UITableView,
                   titleForHeaderInSection section: Int) -> String? {
        return filters!.availableFilterKey(at: section)
    }
}

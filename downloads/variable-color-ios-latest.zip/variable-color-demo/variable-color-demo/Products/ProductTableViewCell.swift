//
//  ProductTableViewCell.swift
//  variable-color-demo
//
//  Created by Wade Gasior on 5/3/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    @IBOutlet var previewView: UIImageView!

    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    @IBOutlet var label3: UILabel!
    @IBOutlet var label4: UILabel!
}

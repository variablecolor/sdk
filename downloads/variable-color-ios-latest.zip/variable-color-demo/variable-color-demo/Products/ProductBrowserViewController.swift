//
//  ProductBrowserViewController.swift
//  variable-color-demo
//
//  Created by Wade Gasior on 5/3/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import Kingfisher
import UIKit
import VariableColor

class ProductBrowserViewController: UIViewController, UISearchBarDelegate {
    var selectedFilters: VCFProductFilterSet?
    var searchText = ""
    private var searchResults: [VCFProductSearchResult] = []
    @IBOutlet var productsTable: UITableView!
    @IBOutlet var selectedFiltersLabel: UILabel!
    @IBOutlet var chooseFiltersButton: UIButton!
    @IBOutlet var scanButton: UIButton!

    public var searchMode = "products" // products or inspirations

    override func viewDidLoad() {
        super.viewDidLoad()

        refreshSearchResults()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender _: Any?) {
        let vc = segue.destination as! FiltersViewController
        if let filters = self.selectedFilters {
            vc.filters = filters
            vc.filterMode = searchMode
        }
        vc.filterChooserDelegate = self
    }

    func applySelectedFilters(toSearch: VCFProductSearch) {
        if let filters = selectedFilters {
            toSearch.filters = filters.selectedFilters
        }
    }

    func applyTextTerm(toSearch: VCFProductSearch) {
        if searchText.lengthOfBytes(using: .utf8) > 0 {
            toSearch.textTerm = "*" + searchText + "*"
        }
    }

    func refreshSearchResults() {
        searchResults = []
        productsTable.reloadData()

        var search: VCFProductSearch
        if searchMode == "products" {
            search = VCFProductSearch()
        } else {
            search = VCFProductSearch.inspirations()
        }

        search.limit = 100
        applySelectedFilters(toSearch: search)
        applyTextTerm(toSearch: search)

        search.execute { results, err in
            guard err == nil else {
                return
            }

            self.searchResults = results
            self.productsTable.reloadData()
        }
    }

    @IBAction func handleScan(_: Any) {
        guard let dev = VCFCentral.connectionManager.connectedDevice else {
            return promptForConnection()
        }

        scanButton.setTitle("scanning...", for: .normal)

        dev.requestColorScan { scan, _, err in
            guard err == nil else {
                return self.showScanFailure(err!)
            }

            var search: VCFProductSearch
            if self.searchMode == "products" {
                search = VCFProductSearch()
            } else {
                search = VCFProductSearch.inspirations()
            }
            search.colorTerm = scan
            self.applySelectedFilters(toSearch: search)

            search.execute { results, _ in
                self.searchResults = results
                self.productsTable.reloadData()
            }

            if let scan = scan {
                self.scanButton.backgroundColor = scan.displayColor
                self.scanButton.setTitle("scan", for: .normal)
            }
        }
    }

    func showScanFailure(_ err: Error) {
        NSLog("Failed to scan: \(err.localizedDescription)")
        DispatchQueue.main.async {
            let ac = UIAlertController(title: "Failed to scan", message: err.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(ac, animated: true, completion: nil)
            self.scanButton.setTitle("scan", for: .normal)
        }
    }

    func promptForConnection() {
        DispatchQueue.main.async {
            let ac = UIAlertController(title: "Device Not Connected", message: "Connect Device to proceed", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "Go Connect", style: .default, handler: { _ in
                // Navigate to connection
                self.navigationController?.popToRootViewController(animated: true)
            }))
            ac.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(ac, animated: true, completion: nil)
        }
    }

    func searchBar(_: UISearchBar,
                   textDidChange searchText: String) {
        self.searchText = searchText
        refreshSearchResults()
    }

    func searchBarSearchButtonClicked(_: UISearchBar) {
        view.endEditing(true)
    }
}

extension ProductBrowserViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return searchResults.count
    }

    func tableView(_: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        productsTable.deselectRow(at: indexPath, animated: false)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "basic-product-cell", for: indexPath) as! ProductTableViewCell

        let sr = searchResults[indexPath.row]
        if let product = sr.product {
            cell.label1.text = product.code
            cell.label2.text = product.name
            cell.label3.text = String(format: "%@ - %@", product.vendor, product.collection)
            cell.previewView.backgroundColor = product.displayColor

            if let image = product.images.first {
                cell.previewView.kf.setImage(with: image.url)
            } else {
                cell.previewView.image = nil
            }
        }

        if let deltaE = sr.deltaE {
            cell.label4.text = String(format: "%0.2f ∆E", deltaE.floatValue)
        } else {
            cell.label4.text = ""
        }

        return cell
    }
}

extension ProductBrowserViewController: FilterChooserProtocol {
    func filtersSelected(filters: VCFProductFilterSet, filterMode: String) {
        selectedFilters = filters
        searchMode = filterMode

        let filterVals: [String] = filters.selectedVals()
        selectedFiltersLabel.text = filterVals.joined(separator: ", ")

        refreshSearchResults()
    }
}

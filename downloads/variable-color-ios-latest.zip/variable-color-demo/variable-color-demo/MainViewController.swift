//
//  ViewController.swift
//  variable-color-demo
//
//  Created by Wade Gasior on 4/23/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit
import VariableColor

class MainViewController: UIViewController {
    @IBOutlet var btnProducts: UIButton!
    @IBOutlet var btnConnect: UIButton!
    @IBOutlet var lblMain: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        btnConnect.isHidden = true
        btnProducts.isHidden = true

      VCFCentral.initWith("SDK_KEY_HERE", delegate: self)
    }
}

// MARK: - VCFCentralDelegate

extension MainViewController: VCFCentralDelegate {
    func onInit(_ err: Error?) {
        guard err == nil else {
            return print("Failed to init SDK: \(err!.localizedDescription)")
        }

        btnConnect.isHidden = false
        btnProducts.isHidden = false
        lblMain.text = "variable color framework demo"

        print("VariableColor initialized using version \(VariableColorVersion)")
    }
}

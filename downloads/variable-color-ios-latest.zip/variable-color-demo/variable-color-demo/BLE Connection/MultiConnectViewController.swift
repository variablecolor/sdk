//
//  MultiConnectViewController
//  variable-color-demo
//
//  Created by Andrew T on 4/25/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit
import VariableColor

class MultiConnectViewController: UIViewController {
    let kSavedCBPUUID: String = "kSavedCBPUUID"

    var savedDeviceUUID: String? {
        return UserDefaults.standard.string(forKey: kSavedCBPUUID)
    }

    var hasSavedDevice: Bool {
        return savedDeviceUUID != nil
    }

    @IBOutlet var btnDisconnect: UIButton!
    @IBOutlet var btnScanColor: UIButton!
    @IBOutlet var btnCal: UIButton!
    @IBOutlet var lbl: UILabel!
    @IBOutlet var lblDevCnt: UILabel!

    func saveDevice(_ device: VCFColorInstrument) {
        let uuid = device.peripheral.identifier.uuidString
        UserDefaults.standard.set(uuid, forKey: kSavedCBPUUID)
    }

    func forgetSavedDevice() {
        return UserDefaults.standard.removeObject(forKey: kSavedCBPUUID)
    }

    func connectToSavedDevice() {
        guard let deviceUUID = savedDeviceUUID else {
            return
        }

        VCFCentral.connectionManager.connectionListener = self
        VCFCentral.connectionManager.connect(toUUID: deviceUUID) { err in
            guard err == nil else {
                return self.showConnectionError(err!)
            }
        }
    }

    func showConnectionError(_ err: Error) {
        let ac = UIAlertController(title: "ERROR", message: err.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Quit", style: .default, handler: { _ in
            self.tabBarController?.navigationController?.popToRootViewController(animated: true)
        }))
        present(ac, animated: true, completion: nil)
    }

    // MARK: - ViewController Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        startConnection()
    }

    func startConnection() {
        // if already connected, show device ready
        if VCFCentral.connectionManager.isConnected {
            return updateForDeviceReady()
        }

        setButtonVisibility(isVisible: false)

        if hasSavedDevice {
            promptToConnectToSavedDevice()
        } else {
            VCFCentral.connectionManager.multiConnectStart(self)
        }
    }

    func promptToConnectToSavedDevice() {
        let ac = UIAlertController(title: "Connect to Saved Device?", message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
            self.connectToSavedDevice()
        }))
        ac.addAction(UIAlertAction(title: "No (forget device)", style: .destructive, handler: { _ in
            self.forgetSavedDevice()
            VCFCentral.connectionManager.multiConnectStart(self)
        }))
        present(ac, animated: true, completion: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        VCFCentral.connectionManager.multiConnectStop()
    }

    func setButtonVisibility(isVisible: Bool) {
        btnDisconnect.isHidden = !isVisible
        btnScanColor.isHidden = !isVisible
        btnCal.isHidden = !isVisible
    }

    @IBAction func btnDisconnectPressed(_: Any) {
        if let dev = VCFCentral.connectionManager.connectedDevice {
            // check if user wants to save ("pair") to this device so we auto-connect next time
            let ac = UIAlertController(title: "Forget Device?", message: "Do you want to save this device for later or forget it?", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "Forget", style: .destructive, handler: { _ in
                self.forgetSavedDevice()
                dev.disconnect()
                // Optionally Restart multiconnect. Redundant if already started, but req'd in case we used connectToSaved()
                VCFCentral.connectionManager.multiConnectStart(self)
            }))
            ac.addAction(UIAlertAction(title: "Remember & Disconnect", style: .default, handler: { _ in
                // Since we are remembering this device - we likely don't want to immediately reconnnect to the device we just disconnected from.
                dev.disconnect()
                self.tabBarController?.navigationController?.popToRootViewController(animated: true)
            }))
            present(ac, animated: true, completion: nil)
        }
    }

    @IBAction func btnScanPressed(_: Any) {
        guard VCFCentral.connectionManager.isConnected else {
            return
        }

        let dev = VCFCentral.connectionManager.connectedDevice!

        dev.requestColorScan { scan, _, err in
            guard err == nil else {
                return self.showScanError(err!)
            }

            if let scan = scan {
                self.view.backgroundColor = scan.displayColor

                // Lab color - 10 deg. observer, D50 illuminant
                let d50Lab10Deg = scan.lab(.tenDeg, illum: .D50)

                // Lab color - 10 deg. observer, D65 illuminant
                let d65Lab10Deg = scan.lab(.tenDeg, illum: .D65)

                // Lab color - 2 deg. observer, D50 illuminant
                let d50Lab2Deg = scan.lab(.twoDeg, illum: .D50)

                // Lab color - 2 deg. observer, D65 illuminant
                let d65Lab2Deg = scan.lab(.twoDeg, illum: .D65)

                // RGB color
                let rgbColor = scan.rgbColor

                // hex color
                let hex = scan.hex

                // LCH color
                let lchColor = scan.lchColor
            }
        }
    }

    func showScanError(_ err: Error) {
        let ac = UIAlertController(title: "Scan Failed", message: err.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true, completion: nil)
    }

    @IBAction func btnCalPressed(_: Any) {
        if let dev = VCFCentral.connectionManager.connectedDevice {
            dev.requestCalibration { (_: Bool, error: Error?) in
                var title = "Cal Done"
                var msg = "Scan on"
                if let err = error {
                    title = "Cal Failed"
                    msg = err.localizedDescription
                }
                let ac = UIAlertController(title: title, message: msg, preferredStyle: .alert)
                ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(ac, animated: true, completion: nil)
            }
        }
    }

    func updateForDeviceReady() {
        lbl.text = "Device Ready"
        lblDevCnt.text = ""
        setButtonVisibility(isVisible: true)

        if let device = VCFCentral.connectionManager.connectedDevice {
            saveDevice(device)
            print("Connected to \(device.serial)")

            device.requestBatt { battStatus, err in
                guard err == nil else {
                    return
                }

                print("device battery percent is \(battStatus.level)")
            }
        }
    }
}

// MARK: - VCFConnectionManagerDelegate

extension MultiConnectViewController: VCFConnectionManagerDelegate {
    func onStateChanged(_ state: VConnectState, discoveredPeripherals count: UInt) {
        switch state {
        case .Disconnected:
            lbl.text = "Disconnected"
            lblDevCnt.text = ""
            setButtonVisibility(isVisible: false)
            break
        case .ScanningForDevices:
            lbl.text = "Scanning BLE - Press button on muse"
            lblDevCnt.text = "\(count) Devices Visible"
            break
        case .ConnectingToDevices:
            lbl.text = "Connecting to devices..."
            break
        case .AwaitingConfirmation:
            lbl.text = "Awaiting confirmation: press muse button again"
            lblDevCnt.text = ""
            break
        case .GettingCalibration:
            lbl.text = "Getting calibration..."
            lblDevCnt.text = ""
            break
        case .DeviceReady:
            updateForDeviceReady()
            break
        }
    }

    func onWarning(_ error: Error) {
        let ac = UIAlertController(title: "Warning", message: error.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true, completion: nil)
    }

    func onError(_ error: Error) {
        // stop trying to multiconnect for now - alert the user and let them decide what to do...
        VCFCentral.connectionManager.multiConnectStop()

        let ac = UIAlertController(title: "ERROR", message: error.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Restart Connection Process", style: .default, handler: { _ in
            VCFCentral.connectionManager.multiConnectStart(self)
        }))
        ac.addAction(UIAlertAction(title: "Quit", style: .default, handler: { _ in
            self.tabBarController?.navigationController?.popToRootViewController(animated: true)
            return
        }))
        present(ac, animated: true, completion: nil)
    }
}

//
//  DirectConnectViewController.swift
//  variable-color-demo
//
//  Created by Andrew T on 4/28/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import CoreBluetooth
import UIKit
import VariableColor

class DirectConnectViewController: UIViewController {
    @IBOutlet var tableView: UITableView!
    var discoveredPeripherals: [VPeripheralWRSSI] = []
    let refreshCtrl = UIRefreshControl()
    let spinner = LabeledSpinner(effect: UIBlurEffect(style: .dark))

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(spinner)

        setupTableView()
    }

    func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        refreshCtrl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshCtrl.addTarget(self, action: #selector(refresh(sender:)), for: .valueChanged)
        tableView.addSubview(refreshCtrl)
        tableView.sendSubview(toBack: refreshCtrl)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        refreshCtrl.beginRefreshing()
        tableView.setContentOffset(CGPoint(x: 0, y: -refreshCtrl.frame.size.height), animated: true)
        VCFCentral.connectionManager.connectionListener = self
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
            self.refreshCtrl.sendActions(for: .valueChanged)
        })
    }

    @objc func refresh(sender _: AnyObject) {
        VCFCentral.connectionManager.bleDiscover(withRestricted: true) { peripherals, err in
            self.tableView.contentOffset = CGPoint.zero
            self.discoveredPeripherals = []

            guard err == nil else {
                return self.showScanError(err!)
            }

            self.discoveredPeripherals = peripherals

            self.tableView.reloadData()
            self.tableView.layoutIfNeeded()
            self.refreshCtrl.endRefreshing()
        }
    }

    func showScanError(_ err: Error) {
        let ac = UIAlertController(title: "BLE Scan Failed", message: err.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true, completion: nil)
    }

    func showConnectionError(_ err: Error) {
        let ac = UIAlertController(title: "Connect Failed", message: err.localizedDescription, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true, completion: nil)
    }

    func connect(_ p: CBPeripheral) {
        VCFCentral.connectionManager.connect(to: p) { err in
            guard err == nil else {
                return self.showConnectionError(err!)
            }

            if let dev = VCFCentral.connectionManager.connectedDevice {
                dev.delegate = self
            }

            self.tableView.reloadData()
        }
    }

    func disconnect() {
        if let connectedDev = VCFCentral.connectionManager.connectedDevice {
            connectedDev.disconnect()
        }
    }

    func peripheralIsConnected(_ p: CBPeripheral) -> Bool {
        if VCFCentral.connectionManager.isConnected == false {
            return false
        }

        if let connectedDev = VCFCentral.connectionManager.connectedDevice {
            if connectedDev.peripheral.identifier.uuidString == p.identifier.uuidString {
                return true
            }
        }

        return false
    }
}

// MARK: - TableView Extension

extension DirectConnectViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in _: UITableView) -> Int {
        return 1
    }

    func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return discoveredPeripherals.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if indexPath.row < discoveredPeripherals.count {
            let p = discoveredPeripherals[indexPath.row]
            cell.textLabel!.text = p.peripheral.identifier.uuidString
            cell.accessoryType = .none

            if peripheralIsConnected(p.peripheral) {
                cell.accessoryType = .checkmark
            }
        }

        return cell
    }

    func tableView(_: UITableView, didSelectRowAt indexPath: IndexPath) {
        let p = discoveredPeripherals[indexPath.row]

        if peripheralIsConnected(p.peripheral) {
            disconnect()
        } else {
            connect(p.peripheral)
        }
    }
}

// MARK: - VColorimeterDelegate Extension

extension DirectConnectViewController: VCFColorInstrumentDelegate {
    func buttonPressed(_: VCFColorInstrument!) {
        NSLog("Button Pressed")
    }

    func onDisconnect(_: VCFColorInstrument!) {
        tableView.reloadData()
    }
}

// MARK: - VConnectionListener Extension

extension DirectConnectViewController: VCFConnectionManagerDelegate {
    func onStateChanged(_ state: VConnectState, discoveredPeripherals _: UInt) {
        switch state {
        case .Disconnected:
            spinner.hide()
            refreshCtrl.attributedTitle = NSAttributedString(string: "Pull to refresh")
            break
        case .ScanningForDevices:
            refreshCtrl.attributedTitle = NSAttributedString(string: "Scanning BLE")
            break
        case .ConnectingToDevices:
            spinner.showWith(title: "Connecting to Device")
            break
        case .AwaitingConfirmation:
            break
        case .GettingCalibration:
            spinner.showWith(title: "Getting calibration data...")
            break
        case .DeviceReady:
            spinner.showWith(title: "Device ready")
            DispatchQueue.main.asyncAfter(deadline: DispatchTime(uptimeNanoseconds: NSEC_PER_SEC)) {
                self.spinner.hide()
            }
            break
        }
    }

    func onWarning(_ error: Error) {
        NSLog("Warning: \(error.localizedDescription)")
    }

    func onError(_ error: Error) {
        NSLog("Error: \(error.localizedDescription)")
    }
}

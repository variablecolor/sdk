//
//  LabeledSpinner.swift
//  variable-color-demo
//
//  Created by Andrew T on 5/3/18.
//  Copyright © 2018 Variable, Inc. All rights reserved.
//

import UIKit

class LabeledSpinner: UIVisualEffectView {
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()

    static func defaultRect(superFrame: CGRect) -> CGRect {
        return CGRect(x: superFrame.midX - superFrame.width * 0.45, y: superFrame.midY - 35 / 2, width: superFrame.width * 0.9, height: 92)
    }

    override init(effect: UIVisualEffect?) {
        super.init(effect: effect)

        frame = LabeledSpinner.defaultRect(superFrame: UIScreen.main.bounds) // CGRect(x: frame.minX, y: frame.minY , width: frame.width, height: frame.height)
        layer.cornerRadius = 15
        layer.masksToBounds = true

        strLabel = UILabel(frame: CGRect(x: 0, y: 10, width: frame.width, height: frame.height * 0.4))
        strLabel.text = ""
        strLabel.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
        strLabel.textAlignment = .center

        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
        activityIndicator.frame = CGRect(x: frame.width * 0.5 - (46 / 2), y: 40, width: 46, height: 46)
        activityIndicator.startAnimating()

        contentView.addSubview(activityIndicator)
        contentView.addSubview(strLabel)
        isHidden = true
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func showWith(title: String?) {
        strLabel.text = title
        isHidden = false
    }

    func hide() {
        isHidden = true
    }

    func remove() {
        strLabel.removeFromSuperview()
        activityIndicator.removeFromSuperview()
        removeFromSuperview()
    }
}

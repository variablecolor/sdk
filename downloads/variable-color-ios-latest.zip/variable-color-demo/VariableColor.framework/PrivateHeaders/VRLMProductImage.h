//
//  VRLMProductImage.h
//  VariableColorFramework
//
//  Created by Wade Gasior on 8/10/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Realm/Realm.h>

@interface VRLMProductImage : RLMObject

@property NSString *key;
@property NSString *url;

@end

#import <Foundation/Foundation.h>
#import "VCFRGBColor.h"
#import "VTColorUtils.h"
@class VCFLabColor;
@class VCFLuvColor;
@class VCFLchColor;

@interface VCFXYZColor : NSObject
// X,Y,Z are 100 base scaled
@property (nonatomic, readonly) double X;
@property (nonatomic, readonly) double Y;
@property (nonatomic, readonly) double Z;
@property (nonatomic, readonly) VCFIlluminant illuminant;
@property (nonatomic, readonly) VCFObserver stdObserver;

// Constructors expect 100 scaled XYZ values
+ (instancetype)XYZColorWithX:(double)x
                            Y:(double)y
                            Z:(double)z
                     usingIll:(VCFIlluminant)illuminant;
+ (instancetype)XYZColorWithX:(double)x
                            Y:(double)y
                            Z:(double)z
                     usingIll:(VCFIlluminant)illuminant
                usingObserver:(VCFObserver)observer;
- (VCFRGBColor *)RGBColorInSpace:(VCFRGBSpace)colorSpace;
- (VCFLuvColor *)toLUV;

- (VCFXYZColor *)toXYZWithIlluminant:(VCFIlluminant)illuminate;
- (VCFLchColor *)toLCH;
- (VCFLabColor *)toLab;
@end

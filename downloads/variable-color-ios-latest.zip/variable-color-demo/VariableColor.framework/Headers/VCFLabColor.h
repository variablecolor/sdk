#import <Foundation/Foundation.h>
#import "VCFLCHColor.h"
#import "VCFXYZColor.h"
#import "VTColorUtils.h"


typedef enum { VTLAB_DE94_GRAPHIC, VTLAB_DE94_TEXTILE } vtlabDE94Type;
typedef enum { VTLAB_DECMC_2_1, VTLAB_DECMC_1_1 } vtlabDEcmcType;

@interface VCFLabColor : NSObject

@property (nonatomic, readonly) double L;
@property (nonatomic, readonly) double A;
@property (nonatomic, readonly) double B;

@property (nonatomic, readonly) VCFIlluminant illuminant;
@property (nonatomic, readonly) VCFObserver stdObserver;

@property (nonatomic, readonly) UIColor *uiColor;
@property (readonly, nonatomic) VCFRGBColor *rgbColor;
@property (readonly, nonatomic) NSString *hex;
@property (readonly, strong) VCFLchColor *lchColor;
@property (nonatomic, readonly) VCFXYZColor *XYZColor;

+ (VCFLabColor *)labColorWithColor:(VCFLabColor *)lab;
- (VCFLabColor *)toLabWithIlluminant:(VCFIlluminant)ill;

- (NSString *)displayString;

+ (instancetype)labColorWithL:(double)l
                            a:(double)a
                            b:(double)b
                     usingIll:(VCFIlluminant)illuminant;

+ (instancetype)labColorWithL:(double)l
                            a:(double)a
                            b:(double)b
                     usingIll:(VCFIlluminant)illuminant
                usingObserver:(VCFObserver)observer;

- (double)deltaE00:(VCFLabColor *)other;
- (double)deltaEcmc:(VCFLabColor *)other dEcmcType:(vtlabDEcmcType)dEcmcType;
- (double)deltaE94:(VCFLabColor *)other dE94Type:(vtlabDE94Type)dE94Type;
- (BOOL)isEqualToLab:(VCFLabColor*)other;

@end

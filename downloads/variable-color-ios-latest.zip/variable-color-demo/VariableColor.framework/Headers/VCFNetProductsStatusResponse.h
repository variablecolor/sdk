//
//  VCFNetProductsStatusResponse.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/7/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFNetProductsStatusResponse : NSObject

@property (strong, nonatomic, readonly) NSDate *productsUpdatedAt;

+ (VCFNetProductsStatusResponse *)responseWithProductsUpdatedAt:(NSDate *)d;

@end

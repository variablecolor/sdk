//
//  VCFColorScan.h
//  VariableColor
//
//  Created by Andrew T on 9/6/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFColorSearchTerm.h"
#import "VCFGenericBatchedLab.h"
#import "VCFSpectralPoint.h"
#import "VTColorUtils.h"

@class VCFLabColor, VCFLchColor, VCFRGBColor, UIColor;

@interface VCFColorScan : NSObject <VCFColorSearchTerm>

+ (void)scanFrom:(NSString *)serial senses:(NSArray *)senses complete:(void (^)(VCFColorScan *scan, NSError *error))complete;

// ColorSearchTerm:
- (VCFLabColor *)auxSearchLab;

- (NSArray<NSObject<VCFBatchedLabColor> *> *_Nonnull)batchedLabsWithIllum:(NSString *)ill obs:(NSString *)obs;

/**
 Returns the Lab color for for this scan in the requested colorspace
 */
- (VCFLabColor *)lab:(VCFObserver)obs illum:(VCFIlluminant)illum;

/**
 Returns the LCH color for this scan's adjustedLab 2˚
 */
- (VCFLchColor *)lchColor:(VCFObserver)obs illum:(VCFIlluminant)illum;

/**
 Returns the UIColor representation of the adjusted 2˚ Lab for display
 */
@property (readonly, nonnull) UIColor *displayColor;

/**
 Returns the VCFRGBColor for this scan (sRGB -  2˚/D65)
 */
@property (readonly, nonnull) VCFRGBColor *rgbColor;

/**
 Returns the hex code for this scan's rgbColor
 */
@property (readonly, nonnull) NSString *hex;

/**
 Returns a spectrum for this scan (only available with Spectro hardware)
 */
@property (readonly, nullable) NSArray<VCFSpectralPoint *> *spectralCurve;

@end

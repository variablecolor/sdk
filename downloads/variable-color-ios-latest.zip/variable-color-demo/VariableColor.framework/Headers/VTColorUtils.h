#ifndef Node_iOS_VTColorUtils_h
#define Node_iOS_VTColorUtils_h

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, VCFObserver) { VCFObserverTwoDeg, VCFObserverTenDeg };

typedef NS_ENUM(NSInteger, VCFIlluminant) {
  VCFIlluminantD50,
  VCFIlluminantD65,
  VCFIlluminantA,
  VCFIlluminantB,
  VCFIlluminantC,
  VCFIlluminantF2,
  VCFIlluminantF7,
  VCFIlluminantF11
};

typedef NS_ENUM(NSInteger, VCFRGBSpace) { VCFRGBSpaceSRGB };

typedef NS_ENUM(NSInteger, VCFDeltaE) { VCFDeltaE2000, VCFDeltaECMC21, VCFDeltaECMC11, VCFDeltaE94GraphicArts, VCFDeltaE94Textiles };

@class VCFLabColor;

@interface VTColorUtils : NSObject
+ (NSArray<NSString *> *)allIlluminants;

+ (NSString *)toIlluminantStr:(VCFIlluminant)ill;
+ (VCFIlluminant)fromIlluminantStr:(NSString *)str;

// 2˚/10˚:
+ (NSString *)toObserverStr:(VCFObserver)ill;
// TWO_DEGREE/TEN_DEGREE:
+ (NSString *)toObserverTextStr:(VCFObserver)observer;
+ (VCFObserver)fromObserverStr:(NSString *)illString;

+ (double)deltaEForSample:(VCFLabColor *)sample withStandard:(VCFLabColor *)std using:(VCFDeltaE)technique;

+ (NSString *)toDeltaEStr:(VCFDeltaE)de;
+ (VCFDeltaE)fromDeltaEStr:(NSString *)s;

@end

#endif

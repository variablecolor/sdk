//
//  VCFProductImage.h
//  VariableColor
//
//  Created by Wade Gasior on 8/13/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFProductImage : NSObject

@property (strong, nonatomic, readonly) NSString *key;
@property (strong, nonatomic, readonly) NSURL *url;

@end

#import <UIKit/UIKit.h>

//! Framework version string for VariableColor
FOUNDATION_EXPORT NSString *const VariableColorVersion;

// public headers of your framework
#import "VCFCentral.h"

#import <CoreBluetooth/CoreBluetooth.h>
#import <Foundation/Foundation.h>

#import "VCFCentral.h"
#import "VCFCentralDelegate.h"
#import "VCFColorScan.h"
#import "VCFColorInstrument.h"
#import "VCFBatteryStatus.h"
#import "VCFConnectionManager.h"
#import "VCFConnectionManagerDelegate.h"
#import "VCFHSBColor.h"
#import "VCFLCHColor.h"
#import "VCFLabColor.h"
#import "VCFLuvColor.h"
#import "VCFNetProductsStatusResponse.h"
#import "VCFProduct.h"
#import "VCFVariableCloudProduct.h"
#import "VCFProductFilterSet.h"
#import "VCFProductDownloaderDelegate.h"
#import "VCFProductKV.h"
#import "VCFProductManager.h"
#import "VCFProductSearch.h"
#import "VCFProductSearchSortDescriptor.h"
#import "VCFProductSearchResult.h"
#import "VCFRGBColor.h"
#import "VCFColorCloudSerialization.h"
#import "VCFGenericColorSearchTerm.h"
#import "VCFGenericBatchedLab.h"
#import "VCFNetCredentials.h"
#import "VCFProductImage.h"
#import "VCFSpectralPoint.h"
#import "VCFProductSpectrum.h"

// General use flow for this framework (Bluetooth)
// 1. User "starts" Variable w/ their API Key (API is a singleton internally)
// 2. User CAN use ConnectionManager to get connected to a Muse
//  - MultiConnect is the same flow as used in our apps (connects to every muse
//  in sight, user confirms via buttonpress)
//  - DirectConnect enables app to directly connect to a CBPeripheral (useful
//  for apps to "pair" devices, etc)
// 3. ConnectionManager has a colorimeter property for taking scans - will be
// populated upon connect success

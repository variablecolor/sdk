//
//  VINetCasAuthResponse.h
//  VariableSDK
//
//  Created by Wade Gasior on 4/23/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFNetCredentials : NSObject

@property (strong, nonatomic, readonly) NSString *sdkKey;

@property (strong, nonatomic, readonly) NSString *sessionToken;
@property (strong, nonatomic, readonly) NSString *subscriptionID;
@property (strong, nonatomic, readonly) NSString *packageID;
@property (strong, nonatomic, readonly) NSString *b2APIKey;
@property (strong, nonatomic, readonly) NSString *platformID;

+ (VCFNetCredentials *)credsWithSDKKey: (NSString *) sdkKey;
+ (VCFNetCredentials *)credsFromDictionary:(NSDictionary *)d;
+ (VCFNetCredentials *)sdkAuthResponseFromDictionary:(NSDictionary *)d;
- (NSDictionary *)headersForColorCloud;

@end

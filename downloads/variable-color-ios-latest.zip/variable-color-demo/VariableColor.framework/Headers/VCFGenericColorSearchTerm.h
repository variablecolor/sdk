//
//  VCFGenericColorSearchTerm.h
//  VariableColor
//
//  Created by Wade Gasior on 6/1/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFColorSearchTerm.h"


////////////////////////////////////////////////////////////////////////////////
@interface VCFGenericColorSearchTerm : NSObject <VCFColorSearchTerm>
////////////////////////////////////////////////////////////////////////////////

@property (readonly) VCFLabColor *auxSearchLab;

- (NSArray<NSObject<VCFBatchedLabColor> *> *_Nonnull)batchedLabsWithIllum:(NSString*)ill obs:(NSString*)obs;

@end

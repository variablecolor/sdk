//
//  VCFLuvColor.h
//  Node_iOS
//
//  Created by Corey Mann on 6/1/15.
//  Copyright (c) 2015 Variable, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFXYZColor.h"
#import "VTColorUtils.h"

@interface VCFLuvColor : NSObject

@property (nonatomic, readonly) double L;
@property (nonatomic, readonly) double u;
@property (nonatomic, readonly) double v;
@property (nonatomic, readonly) VCFIlluminant illuminant;
@property (nonatomic, readonly) VCFObserver stdObserver;

+ (instancetype)luvColorWithL:(double)l
                            u:(double)u
                            v:(double)v
                     usingIll:(VCFIlluminant)illuminant;
+ (instancetype)luvColorWithL:(double)l
                            u:(double)u
                            v:(double)v
                     usingIll:(VCFIlluminant)illuminant
                usingObserver:(VCFObserver)observer;

- (VCFXYZColor *)toXYZ;

@end

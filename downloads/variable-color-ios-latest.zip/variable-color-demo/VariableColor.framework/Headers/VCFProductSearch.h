#import <Foundation/Foundation.h>
#import "VCFColorSearchTerm.h"
#import "VCFProductFilterSet.h"
#import "VCFColorSearchOptions.h"

@class VCFLabColor, VCFProductSearchResult, VCFProductKV, VCFProductSearchSortDescriptor;

typedef enum SearchType : NSUInteger {
  SearchTypeProducts = 0,
  SearchTypeInspirations = 1,
} SearchType;

@interface VCFProductSearch : NSObject

/**
  Returns a new instance for searching products
 */
+ (VCFProductSearch *) productSearch;

/**
 Returns a new instance for searching inspirations
 */
+ (VCFProductSearch *) inspirationsSearch;


/**
  Set to true in order to prefer searching using remote servers vs rather than local data
 **/
@property (nonatomic) BOOL preferOnline;

/**
 Search type - used to specify whether to search products or inspirations
 */

@property (nonatomic) SearchType searchType;

/**
 Used to filter products.
 This is typically set using the `selectedFilters` property of `VCFProductFilterSet`
 
 If null, all products are searched.

 */
@property (strong, nonatomic) NSArray<VCFProductKV *> *_Nullable filters;

/**
 Colorterm used for color searches. If this is set, the textTerm is ignored.
 Results will always be sorted by ∆E.
 */
@property (strong, nonatomic) NSObject<VCFColorSearchTerm> *_Nullable colorTerm;

/**
 Options for color searching (delta e method, illuminant, observer, etc)
 */
@property (strong, nonatomic) VCFColorSearchOptions *colorSearchOptions;

/**
 Used for text searches. Every product attribute value is searched for values containing
 the text term.
 */
@property (strong, nonatomic) NSString *_Nullable textTerm;

/**
 Sortkey - key used to sort results by. Ignored if doing a color search.
 Use [VCFProductSearch validSortKeys] to get a list of the allowed keys.
 
 DEPRECATED: Set the sortDescriptors property, which accepts an array
 */
@property (strong, nonatomic) NSString *_Nullable sortKey __deprecated_msg("Use the sortDescriptors property");

/**
 Set to true to sort results in ascending order.
 Ignored if doing a color search.
 
 DEPRECATED: Set the sortDescriptors property, which accepts an array
 */
@property (nonatomic) bool sortAscending __deprecated_msg("Use the sortDescriptors property");

/**
 Array of VCFProductSearchSortDescriptor used to sort search results. Ignored if doing a color search.
 */
@property (strong, nonatomic) NSArray<VCFProductSearchSortDescriptor *> *_Nullable sortDescriptors;

/**
 Number of results returned will not be greater than this number.
 */
@property (nonatomic) NSUInteger limit;

/**
 The first N results will not be returned (use for paging)
 */
@property (nonatomic) NSUInteger skip;

/**
  Returns a list of valid strings that sortKey can be set to.
 */
+ (NSArray<NSString *> *_Nonnull)validSortKeys;

/**
  Checks if we have access to Inspirations
 
  callback is fired when complete
 */
+ (void)checkForInspirationsAccess:(void (^_Nonnull)(bool hasInspirationsAccess, NSError *_Nullable error))onComplete;
- (void)checkForInspirationsAccess:(void (^_Nonnull)(bool hasInspirationsAccess, NSError *_Nullable error))onComplete;

/**
 Executes the search
 Callback is called when complete.
 */
- (void)execute:(void (^_Nonnull)(NSArray<VCFProductSearchResult *> *_Nonnull results, NSError *_Nullable error))onComplete;

/**
 Fetches ALL product filters
 
 callback is fired when complete
 */
+ (void)fetchProductFilters:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;
- (void)fetchProductFilters:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;

/**
 Fetches product filters using a `VCFProductFilterSet`

 callback is fired when complete
 */
+ (void)fetchProductFiltersUsingFilter:(VCFProductFilterSet *_Nullable)filter
                     completionHandler:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;
- (void)fetchProductFiltersUsingFilter:(VCFProductFilterSet *_Nullable)filter
                            completionHandler:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;

/**
 Fetches ALL inspiration filters
 
 callback is fired when complete
 */
+ (void)fetchInspirationFilters:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;
- (void)fetchInspirationFilters:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;

/**
 Fetches inspiration filters using a `VCFProductFilterSet`
 
 callback is fired when complete
 */
+ (void)fetchInspirationFiltersUsingFilter:(VCFProductFilterSet *_Nullable)filter
                         completionHandler:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;

- (void)fetchInspirationFiltersUsingFilter:(VCFProductFilterSet *_Nullable)filter
                     completionHandler:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull availableFilters, NSError *_Nullable error))onComplete;

@end

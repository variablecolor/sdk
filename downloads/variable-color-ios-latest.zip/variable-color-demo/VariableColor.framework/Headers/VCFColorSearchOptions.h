//
//  VCFColorSearchOptions.h
//  VariableColor
//
//  Created by Wade Gasior on 9/20/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VTColorUtils.h"

@interface VCFColorSearchOptions : NSObject

@property (nonatomic) VCFDeltaE deltaEMethod;
@property (nonatomic) VCFIlluminant illuminant;
@property (nonatomic) VCFObserver observer;

+ (VCFColorSearchOptions *) defaultOptions;

@end

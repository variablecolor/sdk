#import <Foundation/Foundation.h>
#import "VCFBatchedLabColor.h"

@class NSString, VCFLabColor;

////////////////////////////////////////////////////////////////////////////////
@interface VCFGenericBatchedLab : NSObject <VCFBatchedLabColor>
////////////////////////////////////////////////////////////////////////////////

@property (readonly, nonnull) VCFLabColor *lab;
@property (readonly, nonnull) NSString *batch;

@property (readonly, nonnull) NSString *hex;

NS_ASSUME_NONNULL_BEGIN

+ (VCFGenericBatchedLab *)batchedLabWith:(VCFLabColor *)lab batch:(NSString *)batch;

NS_ASSUME_NONNULL_END

@end

//
//  VCFProductManager.h
//  Variable
//
//  Created by Andrew T on 4/20/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import "VCFProductDownloaderDelegate.h"
#import "VariableColor.h"

@class VCFNetProductsStatusResponse;

@interface VCFProductManager : NSObject

NS_ASSUME_NONNULL_BEGIN

/**
  Checks if it is necessary to download products. This will return true if products have never been
  downloaded or if products have been updated on the server since the last download

  @param onComplete - callback used when check is complete
 */
- (void)checkIfProductDownloadRequired:(void (^)(BOOL downloadRequired, NSError *_Nullable error))onComplete;

/**
  Download products from server and store them locally.
  The delegate will be informed of progress

 @param delegate Object to handle progress / error calls
 */
- (void)downloadProductsWithDelegate:(NSObject<VCFProductDownloaderDelegate> *)delegate;

/**
  Cancels an ongoing product download
 */
- (void)cancelDownload;

/**
  Fetch product status (date products were last updated on server).
  This could be used to determine if you want to perform a product download.
  The checkIfProductDownloadRequired method uses this internally.
 */
- (void)fetchProductsStatus:(void (^)(VCFNetProductsStatusResponse *status, NSError *_Nullable error))onComplete;

/**
  Get a count of downloaded (stored) products
 */
- (void)countDownloadedProducts:(void (^)(NSNumber *, NSError *_Nullable error))onComplete;

NS_ASSUME_NONNULL_END

@end

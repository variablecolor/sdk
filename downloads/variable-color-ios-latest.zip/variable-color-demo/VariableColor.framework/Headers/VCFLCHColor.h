//
//  VCFLCHColor.h
//  Node_iOS
//
//  Created by Wade Gasior on 1/8/15.
//  Copyright (c) 2015 Variable, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VTColorUtils.h"

@class VCFLabColor;

@interface VCFLchColor : NSObject

@property (nonatomic, readonly) double L;
@property (nonatomic, readonly) double c;
@property (nonatomic, readonly) double h;
@property (readonly, nonatomic) VCFIlluminant illuminant;
@property (nonatomic, readonly) VCFObserver stdObserver;

+ (VCFLchColor *)LchColorWithL:(double)L
                             c:(double)c
                             h:(double)h
                      usingIll:(VCFIlluminant)illuminant;

+ (VCFLchColor *)LchColorWithL:(double)L
                             c:(double)c
                             h:(double)h
                      usingIll:(VCFIlluminant)illuminant
               withStdObserver:(VCFObserver)observer;

- (VCFLabColor *)toLAB;
@end

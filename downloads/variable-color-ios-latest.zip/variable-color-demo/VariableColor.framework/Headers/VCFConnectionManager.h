//
//  VCFConnectionManager.h
//  Variable
//
//  Created by Andrew T on 4/19/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import "VCFColorInstrument.h"
#import "VCFConnectionManagerDelegate.h"
#import "VariableColor.h"
#import "VPeripheralWRSSI.h"

@class VCFColorInstrument;

@interface VCFConnectionManager : NSObject
/**
 * Get connected Color Instrument (if connected)
 * Returns null if not connected
 */
@property (readonly) VCFColorInstrument *_Nullable connectedDevice;

@property (readonly) BOOL isConnected;

NS_ASSUME_NONNULL_BEGIN

/**
 * Can optionally monitor connection state even when using callbacks
 * (can be useful to display finegrained info to user such as "downloading cal data")
 */
@property (weak, nonatomic) NSObject<VCFConnectionManagerDelegate> *_Nullable connectionListener;

#pragma mark - multiconnect flow
/**
 * Start multiconnect to discover and connect muse device
 * Connects to all advertising muses - user presses button on muse to confirm device for use
 *
 * @param listener - listener that implements VCFConnectionManagerDelegate protocol
 */
- (void)multiConnectStart:(id<VCFConnectionManagerDelegate>)listener;
- (void)multiConnectStart;

/**
 * Stops multiconnect flow (does not disconnect device)
 */
- (void)multiConnectStop;

#pragma mark - "Saved Device Connection Flow"
/**
 * Connect to a specific Device based on a given device's CBPeripehral UUID,
 *
 * @param completion - called upon complete. If error -> connection failed,
 *                      otherwise - fetch and use VCFColorInstrument for scans via connectedDevice
 */
- (void)connectToUUID:(NSString *)uuid onSuccess:(void (^)(NSError *_Nullable))completion;

/**
 * Connect to a specific Device based on a given device's Serial number,
 *
 * @param completion - called upon complete. If error -> connection failed,
 *                      otherwise - fetch and use VCFColorInstrument for scans via connectedDevice
 */
- (void)connectToSerial:(NSString *)serial onSuccess:(void (^)(NSError *_Nullable))completion;

/**
 * Halts the saved connection methods after discovery instead of letting them complete
 *
 */
- (void)haltConnect;

#pragma mark - direct connection callback flow

/**
 * Discover devices -
 * Scans for BLE devices for 3s,
 *
 * @param doubleClickOnly - restricts discovery to devices that have been double clicked only
 * @param completion - responds w/ array of CBPeripherals (or error if scan failed)
 */
- (void)bleDiscoverWithRestricted:(BOOL)doubleClickOnly onDiscovered:(void (^)(NSArray<VPeripheralWRSSI *> *, NSError *_Nullable))completion;
/**
 * Connect to a specific CBPeripheral,
 *
 * @param completion - called upon complete. If error -> connection failed,
 *                      otherwise - fetch and use VCFColorInstrument for scans via connectedDevice
 */
- (void)connectTo:(CBPeripheral *)peripheral onSuccess:(void (^)(NSError *_Nullable))completion;

NS_ASSUME_NONNULL_END

@end

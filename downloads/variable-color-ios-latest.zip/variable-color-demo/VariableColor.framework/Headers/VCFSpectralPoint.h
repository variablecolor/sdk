//
//  VCFSpectralPoint.h
//  VariableColor
//
//  Created by Corey Mann on 9/8/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFSpectralPoint : NSObject
@property (nonatomic, readonly) NSUInteger wavelength;
@property (nonatomic, readonly) NSNumber* intensity;

-(id) initWithWavelength:(NSUInteger)nm withIntensity: (NSNumber*) intensity;
@end

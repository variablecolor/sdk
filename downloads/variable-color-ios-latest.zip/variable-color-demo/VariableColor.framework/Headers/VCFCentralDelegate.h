#import <Foundation/Foundation.h>

@protocol VCFCentralDelegate <NSObject>

/**
 * Indicates the SDK initialization is complete,
 *  Executs on main thread/queue
 *  Implementer can retrieve SDK instance via [VCFCentral sharedInstance]
 *
 * @param error - Error in case of initialization failed
 */
- (void)onInit:(nullable NSError *)error;

@end

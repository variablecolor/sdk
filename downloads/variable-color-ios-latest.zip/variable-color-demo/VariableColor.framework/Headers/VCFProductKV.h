//
//  VCFVariableCloudProductFilter.h
//  VariableSDK
//
//  Created by Wade Gasior on 4/25/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFProductKV : NSObject

@property (strong, nonatomic, readonly) NSString *key;
@property (strong, nonatomic, readonly) NSString *keyTranslated;

@property (strong, nonatomic, readonly) NSString *val;
@property (strong, nonatomic, readonly) NSString *valTranslated;

+ (VCFProductKV *)kvWithKey:(NSString *)key val:(NSString *)val;
+ (VCFProductKV *)key:(NSString *)key val:(NSString *)val;

- (NSPredicate *)filterPredicate;

+ (NSArray<VCFProductKV *> *)sortedKVs:(NSArray<VCFProductKV *> *)kvs;
+ (NSDictionary<NSString *, NSArray<VCFProductKV *> *> *)kvsByKey:(NSArray<VCFProductKV *> *)kvs;

@end

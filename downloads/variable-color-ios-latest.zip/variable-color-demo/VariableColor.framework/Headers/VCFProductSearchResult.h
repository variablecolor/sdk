//
//  VCFProductSearchResult.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/1/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFColorSearchTerm.h"
#import "VCFProduct.h"

@class VCFVariableCloudProduct;

@interface VCFProductSearchResult : NSObject

@property (strong, nonatomic, readonly) NSNumber *deltaE;
@property (strong, nonatomic, readonly) NSObject<VCFProduct> *product;

+ (VCFProductSearchResult *)searchResult:(VCFVariableCloudProduct *)p withDeltaE:(float)de;

+ (VCFProductSearchResult *)searchResult:(VCFVariableCloudProduct *)p;

@end

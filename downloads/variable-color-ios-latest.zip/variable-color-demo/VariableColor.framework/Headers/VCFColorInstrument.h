//
//  VCFColorInstrument.h
//  VariableColor
//
//  Created by Andrew T on 9/4/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import "VCFColorScan.h"
#import "VTColorUtils.h"
#import "VariableColor.h"

@class VCFColorInstrument, VCFBatteryStatus;

@protocol VCFColorInstrumentDelegate <NSObject>

/**
 * Indicates this colorimeter's hardware button was pressed
 *
 * @param device - colorimeter in question
 */
- (void)buttonPressed:(VCFColorInstrument *)device;

/**
 * Indicates this colorimeter BLE disconnected
 * If this was an unintended disconnect, will have to go back to connect flow.
 *
 * @param device - colorimeter in question
 */
- (void)onDisconnect:(VCFColorInstrument *)device;
@end


@interface VCFColorInstrument : NSObject

@property (weak, nonatomic) id<VCFColorInstrumentDelegate> delegate;

@property (strong, nonatomic, readonly) CBPeripheral *peripheral;
@property (strong, nonatomic, readonly) NSString *serial;
@property (strong, nonatomic, readonly) NSString *firmwareVersion;
@property (strong, nonatomic, readonly) NSString *model;

/**
 * Disconnect from Colorimeter - BLE connection.
 */
- (void)disconnect;

/**
 * Send BLE notice to Colorimeter device to confirm BLE connection.
 */
- (void)confirmConnection;

/**
 * Performs a color scan and performs the math.
 *
 * @param completion - completion block (if Error, color reading invalid).
 */
- (void)requestColorScan:(void (^)(VCFColorScan *, VCFColorScan *, NSError *))completion;

/**
 * Request white point calibration. <br />
 *
 * Before invoking this method, it is suggested to alert the user to place the cap on the device
 * before continuing.
 *
 * The device should be calibrated not only @ every connection, but after significant amounts of time
 *  (ie - if keep alive is in use, and the user is going to scan 1000 scans, it's recommended to calibrate every
 *  1~5 minutes.)
 *
 * @param completion - completion block (if Error, calibration failed and is now nil).
 */
- (void)requestCalibration:(void (^_Nonnull)(BOOL, NSError *_Nullable))completion;

/**
 * Check if calibrated this session.
 *
 * Indicates if the device has been calibrated upon connection.
 * The device should be calibrated not only @ every connection, but after significant amounts of time
 *  (ie - if keep alive is in use, and the user is going to scan 1000 scans, it's recommended to calibrate every
 *  1~5 minutes.)
 * @return BOOL - has been calibrated
 */
- (BOOL)hasCalibration;

/**
 * Request Battery Level/Charging Status. <br />
 *
 * @param completion - completion block (percent 0~100, voltage, fully charged (charger not active,
 * isOnPower: dev connected to outlet/etc).
 */
- (void)requestBatt:(void (^_Nonnull)(VCFBatteryStatus *_Nonnull, NSError *_Nullable error))completion;

/**
 * Disabled by default.
 *
 * Keep alive prevents a connected colorimeter from automatically disconnecting after 5 minutes of
 * no scanning
 * @param enable -
 */
- (void)setKeepAlive:(BOOL)enable;


@end

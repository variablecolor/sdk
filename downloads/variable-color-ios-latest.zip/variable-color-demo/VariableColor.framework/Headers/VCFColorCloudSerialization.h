//
//  VCFColorCloudSerialization.h
//  VariableColorFramework
//
//  Created by Wade Gasior on 5/30/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFBatchedLabColor.h"
#import "VCFProduct.h"

@class VCFVariableCloudProduct, VCFProductKV, VCFProductBatchedLabColor, VCFColorScan, VCFGenericBatchedLab, VCFProductSearch, VCFProductSearchResult, VCFGenericColorSearchTerm,
    VCFProductFilterSet;

@interface VCFColorCloudSerialization : NSObject

#pragma mark - products
+ (VCFVariableCloudProduct *)productFromDictionary:(NSDictionary *)d;
+ (VCFVariableCloudProduct *)productFromData:(NSData *)d;

+ (NSArray<VCFVariableCloudProduct *> *)productsFromJSONLData:(NSData *)d;

+ (NSDictionary *)productToDictionary:(NSObject<VCFProduct> *)p;

#pragma mark - KVs
+ (NSArray<VCFProductKV *> *)kvsFromArray:(NSArray<NSDictionary *> *)a;
+ (VCFProductKV *)kvFromDictionary:(NSDictionary *)d;
+ (NSDictionary *)kvToDictionary:(VCFProductKV *)kv;
+ (NSArray<NSDictionary *> *)kvsToArray:(NSArray<VCFProductKV *> *)kvs;

#pragma mark - colors
/**
 This creates an array of VCFProductBatchedLabColor from a server JSON array such as:

 [
 {
 "comp": 100,
 "hex": "#726759",
 "name": "SW 7033",
 "lab": {
   "d50L": 44.527695734044904,
   "d50a": 2.921311754222111,
   "d50b": 9.643757498044803
 },
 "mcs": [ ... ]
 },
 { ... },
 { ... },
 ]

 */
+ (NSArray<VCFProductBatchedLabColor *> *)measuredColorsFromJSON:(NSArray<NSDictionary *> *)colorsJSON;

// Dictionary -> VCFColorScan
+ (VCFColorScan *)colorScanFromDictionary:(NSDictionary *)d;

// VCFColorScan -> Dictionary
+ (NSDictionary *)colorScanToDictionary:(VCFColorScan *)scan;

// VCFLabColor -> Dictionary
+ (NSDictionary *)labColorToDictionary:(VCFLabColor *)lab;

// Dictionary -> VCFLabColor
+ (VCFLabColor *)labColorFromDictionary:(NSDictionary *)d;

// Dictionary -> VCFGenericBatchedLab
+ (VCFGenericBatchedLab *)batchedLabfromDictionary:(NSDictionary *)d;

// VCFBatchedLabColor -> Dictionary
+ (NSDictionary *)batchedLabToDictionary:(NSObject<VCFBatchedLabColor> *)blab;

// []Dictionary -> []VCFGenericBatchedLab
+ (NSArray<VCFGenericBatchedLab *> *)batchedLabsFromArray:(NSArray<NSDictionary *> *)array;

// []VCFBatchedLabColor -> []Dictionary
+ (NSArray<NSDictionary *> *)batchedLabsToArray:(NSArray<NSObject<VCFBatchedLabColor> *> *)array;

// VCFProductSearch -> Dictionary
+ (NSDictionary *)productSearchToDictionary:(VCFProductSearch *)search;

// VCFProductSearch -> Dictionary (for Color Cloud search server)
+ (NSDictionary *)productSearchToServerDictionary:(VCFProductSearch *)search;

// Dictionary -> VCFProductSearch
+ (VCFProductSearch *)productSearchFromDictionary:(NSDictionary *)d;

// VCFProductSearchResult -> Dictionary
+ (NSDictionary *)productSearchResultToDictionary:(VCFProductSearchResult *)searchResult;

// []VCFProductSearchResult -> []Dictionary
+ (NSArray<NSDictionary *> *)productSearchResultsToArray:(NSArray<VCFProductSearchResult *> *)searchResults;

// Dictionary -> VCFGenericColorSearchTerm
+ (VCFGenericColorSearchTerm *)colorTermFromDictionary:(NSDictionary *)d;

// VCFProductFilterSet -> Dictionary
+ (NSDictionary *)filterSetToDictionary:(VCFProductFilterSet *)filterSet;

+ (NSDictionary *)filterSetToServerDictionary:(VCFProductFilterSet *)filterSet;

+ (VCFProductFilterSet *)filterSetFromServerDictionary:(NSDictionary *)d;

+ (VCFProductFilterSet *)inspirationsFilterSetFromServerDictionary:(NSDictionary *)d;

// Dictionary -> VCFProductFilterSet
+ (VCFProductFilterSet *)filterSetFromDictionary:(NSDictionary *)d;

@end

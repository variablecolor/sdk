//
//  VPeripheralWRSSI.h
//  VariableColor
//
//  Created by Andrew T on 9/5/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>


@interface VPeripheralWRSSI : NSObject

@property (strong, nonatomic) CBPeripheral *peripheral;
@property (strong, nonatomic) NSNumber *rssi;
@property (strong, nonatomic) NSString* serviceUUID;


+ (NSString*)getServiceUUID:(NSDictionary<NSString *, id> *)advertisementData;
+ (NSString*)serviceUUIDforPeripheral:(CBPeripheral*)p inArray:(NSArray<VPeripheralWRSSI*>*)array;
+ (VPeripheralWRSSI *)with:(CBPeripheral *)peripheral rssi:(NSNumber *)rssi uuid:(NSString*)serviceUUID;
- (BOOL)samePer:(VPeripheralWRSSI *)other;
- (BOOL)containsPer:(CBPeripheral *)p;
+ (NSArray<VPeripheralWRSSI *> *)arrayFromPlainPeripherals:(NSArray<CBPeripheral *> *)ps withUUID:(NSString*)uuid;
- (NSString*)serial;

@end


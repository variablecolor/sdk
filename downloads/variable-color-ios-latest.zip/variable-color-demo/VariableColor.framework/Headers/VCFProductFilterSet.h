//
//  VCFProductFilterSet.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/10/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFProductFilterSet.h"

@class VCFProductKV, VCFOnlineInspirationsFilterSet, VCFOnlineProductFilterSet;

////////////////////////////////////////////////////////////////////////////////
@interface VCFProductFilterSet : NSObject
////////////////////////////////////////////////////////////////////////////////

@property (readonly, nonnull) NSArray<VCFProductKV *> *allFilters;
@property (readonly, nonnull) NSArray<VCFProductKV *> *selectedFilters;
@property (readonly, nonnull) NSArray<VCFProductKV *> *availableFilters;

@property (readonly, nonnull) NSDictionary<NSString *, NSArray<VCFProductKV *> *> *allFiltersByKey;
@property (readonly, nonnull) NSDictionary<NSString *, NSArray<VCFProductKV *> *> *selectedFiltersByKey;
@property (readonly, nonnull) NSDictionary<NSString *, NSArray<VCFProductKV *> *> *availableFiltersByKey;

@property (readonly, nonnull) NSPredicate *selectedFiltersPredicate;
@property (readonly, nonnull) NSPredicate *searchPredicate;

NS_ASSUME_NONNULL_BEGIN
- (void)selectFilter:(VCFProductKV *)f onComplete:(void (^)(VCFProductFilterSet *, NSError *_Nullable error))onComplete;
- (void)deselectFilter:(VCFProductKV *)f onComplete:(void (^)(VCFProductFilterSet *, NSError *_Nullable error))onComplete;
- (void)toggleFilter:(VCFProductKV *)f onComplete:(void (^)(VCFProductFilterSet *, NSError *_Nullable error))onComplete;

- (NSInteger)availableFiltersKeyCount;
- (NSInteger)availableFiltersValCountForKey:(NSString *)key;
- (NSInteger)availableFiltersValCountForKeyAtIndex:(NSInteger)keyIndex;
- (NSString *)availableFilterKeyAtIndex:(NSInteger)index;
- (VCFProductKV *)availableFilterAtIndexPath:(NSIndexPath *)indexPath;

- (BOOL)filterIsSelected:(VCFProductKV *)kv;
- (NSArray<NSString *> *)selectedVals;
- (void)updateAvailableFilters:(void (^)(VCFProductFilterSet *filters, NSError *error))onComplete;

- (void)load:(void (^)(VCFProductFilterSet *, NSError *_Nullable error))onComplete __deprecated_msg("Use the fetchFilters... methods from VCFProductSearch.");

NS_ASSUME_NONNULL_END

+ (VCFProductFilterSet *_Nonnull)filterSetWithSelectedFilters:(NSArray<VCFProductKV *> *_Nonnull)filters;
+ (nonnull VCFProductFilterSet *)filterSetWithFilters:(NSArray<VCFProductKV *> *_Nonnull)filters;

+ (void)filterSet:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull filters, NSError *_Nullable error))onComplete __deprecated_msg("use productsFilterSet or inspirationsFilterSet.");

+ (void)offlineProductsFilterSet:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull filters, NSError *_Nullable error))onComplete;
+ (void)offlineInspirationsFilterSet:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull filters, NSError *_Nullable error))onComplete;

+ (void)onlineProductsFilterSet:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull filters, NSError *_Nullable error))onComplete;
+ (void)onlineInspirationsFilterSet:(void (^_Nonnull)(VCFProductFilterSet *_Nonnull filters, NSError *_Nullable error))onComplete;

+ (VCFProductFilterSet *_Nonnull)emptyFilterSet;

@end

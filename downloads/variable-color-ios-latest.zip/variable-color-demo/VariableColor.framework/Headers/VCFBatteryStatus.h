//
//  VCFBatteryStatus.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/18/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFBatteryStatus : NSObject

/**
 The battery level expressed as a float between 0 (empty) and 1 (fully charged)
 */
@property (readonly) float level;

/**
 The battery level in volts
 */
@property (readonly) float volts;

/**
 Returns true if the battery is fully charged
 */
@property (readonly) BOOL isFullyCharged;

/**
 Returns true if the device is connected to power
 */
@property (readonly) BOOL isOnPower;

@end

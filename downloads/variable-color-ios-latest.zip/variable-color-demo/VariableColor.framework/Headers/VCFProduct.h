#import <Foundation/Foundation.h>

@class UIColor, VCFProductKV, VCFLabColor, VCFProductBatchedLabColor, VCFProductImage, VCFProductSpectrum;

@protocol VCFProduct

NS_ASSUME_NONNULL_BEGIN

@property (readonly) NSString *uuid;
@property (readonly) NSString *code;
@property (readonly) NSString *name;
@property (readonly) NSString *vendor;
@property (readonly) NSString *collection;

@property (readonly) UIColor *displayColor;
@property (readonly) NSArray<VCFLabColor *> *colors;
@property (readonly) NSArray<VCFProductBatchedLabColor *> *internalColors;
@property (readonly) NSArray<VCFProductSpectrum*> *spectra;

@property (readonly) NSArray<VCFProductKV *> *attributes;
@property (readonly) NSArray<VCFProductKV *> *filters;
@property (readonly) NSArray<VCFProductImage *> *images;

NS_ASSUME_NONNULL_END

@end

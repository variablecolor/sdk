//
//  VCFColorSearchTerm.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/1/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFGenericBatchedLab.h"
#import "VTColorUtils.h"

@class VCFLabColor;

////////////////////////////////////////////////////////////////////////////////
@protocol VCFColorSearchTerm
////////////////////////////////////////////////////////////////////////////////

@required
//Backup lab color used for searching when no batched labs available
//2˚/D50
- (VCFLabColor *_Nullable)auxSearchLab;
- (NSArray<NSObject<VCFBatchedLabColor> *> *_Nonnull)batchedLabsWithIllum:(NSString *_Nullable)ill obs:(NSString *_Nullable)obs;

@end

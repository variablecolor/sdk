//
//  VCFBatchedLabColor.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/23/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VCFLabColor;

@protocol VCFBatchedLabColor <NSObject>

@required
@property (readonly, nonnull) VCFLabColor *lab;
@property (readonly, nonnull) NSString *batch;

@end

//
//  VCFProductSearchSortDescriptor.h
//  VariableColor
//
//  Created by Wade Gasior on 7/26/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VCFProductSearchSortDescriptor : NSObject

/**
 Sortkey - key used to sort results by. Ignored if doing a color search.
 Use [VCFProductSearch validSortKeys] to get a list of the allowed keys.
 */
@property (strong, nonatomic) NSString *_Nullable sortKey;

/**
 Set to true to sort results in ascending order.
 */
@property (nonatomic) bool ascending;

+ (VCFProductSearchSortDescriptor *) sortDescriptorWithKey: (NSString *)key ascending: (bool)sortAscending;

@end

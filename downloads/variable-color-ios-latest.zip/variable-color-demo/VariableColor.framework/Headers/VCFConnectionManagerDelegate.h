//
//  VCFConnectionManagerDelegate.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/17/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, VConnectState) {
  Disconnected = 1,
  ScanningForDevices = 2,
  ConnectingToDevices = 3,
  AwaitingConfirmation = 4,
  GettingCalibration = 5,
  DeviceReady = 6,
};

////////////////////////////////////////////////////////////////////////////////
@protocol VCFConnectionManagerDelegate <NSObject>
////////////////////////////////////////////////////////////////////////////////

/**
 * Indicates this BLE Connection state has changed (see above Enum)
 *
 * @param state - the new connection state (see above enum)
 * @param count - # of visible BLE peripherals when in ScanningForDevices state
 */
- (void)onStateChanged:(VConnectState)state discoveredPeripherals:(NSUInteger)count;

/**
 * Indicates warning state (ie - in multiconnect - never got a button press confirm)
 * Multiconnect state machine won't stop - will reset back to disconnected -> scanning
 *
 * @param error - warning message
 */
- (void)onWarning:(NSError *_Nonnull)error;

/**
 * Indicates error trying to connect. Stops multiconnect state machine
 *
 * @param error - cause for fail
 */
- (void)onError:(NSError *_Nonnull)error;

@end

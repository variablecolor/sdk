//
//  VCFCentral.h
//  Variable
//
//  Created by Andrew T on 4/19/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import "VCFCentralDelegate.h"
#import "VariableColor.h"

@class VCFCentral, VCFProductManager, VCFConnectionManager, VCFNetCredentials;

@interface VCFCentral : NSObject

///---------------------
/// @name Initialization
///---------------------

/**
 * Initializes the framework.
 *
 * @param apiKey - Key provided from Variable
 * @param delegate - subscribe to this to be notified when framework is ready for use
 */
+ (void)initWith:(NSString *)apiKey delegate:(id<VCFCentralDelegate>)delegate;


/**
 * Initializes the framework.
 *
 * @param apiKey - Key provided from Variable
 * @param onComplete - callback fired when API is either ready for use or an error occurred during inititialization
 */
+ (void)initWith:(NSString *)apiKey onComplete:(void (^)(NSError *))onComplete;

///---------------------
/// @name Initialization (using VCFNetCredentials)
///---------------------

/**
 * Initializes the framework using an existing VCFNetCredentials object. This is only for advanced
 * use cases and can be ignored by most users.
 *
 * @param creds - Instance of VCFNetCredentials
 * @param delegate - subscribe to this to be notified when framework is ready for use
 */
+ (void)initWithCreds:(VCFNetCredentials *)creds delegate:(id<VCFCentralDelegate>)delegate;

///---------------------
/// @name Properties
///---------------------

/**
 * Returns the shared instance, creating it if necessary.
 **/
@property (class, readonly) VCFCentral *sharedInstance;

/**
 * Returns true if framework has been initialized
 */
@property (class, readonly) BOOL isInitialized;

/**
 * The connection manager used to connect to Variable Color Muse and other colorimeter devices
 * Refer to VCFConnectionManager.h
 */
@property (readonly) VCFConnectionManager *connectionManager;

/**
 * The connection manager used to connect to Variable Color Muse and other colorimeter devices
 * Refer to VCFConnectionManager.h
 */
@property (class, readonly) VCFConnectionManager *connectionManager;

/**
 * The product manager is used to download, browse and search products
 * Refer to VCFProductManager.h
 */
@property (readonly) VCFProductManager *productManager;

/**
 * The product manager is used to download, browse and search products
 * Refer to VCFProductManager.h
 */
@property (class, readonly) VCFProductManager *productManager;

@end

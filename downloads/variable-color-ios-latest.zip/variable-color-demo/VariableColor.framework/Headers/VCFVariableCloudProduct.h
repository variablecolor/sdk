//
//  VCFVariableCloudProduct.h
//  VariableSDK
//
//  Created by Wade Gasior on 4/25/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFColorSearchTerm.h"
#import "VCFProduct.h"

@class VCFroductKV, VCFProductBatchedLabColor;

@interface VCFVariableCloudProduct : NSObject <VCFProduct, VCFColorSearchTerm>

@end

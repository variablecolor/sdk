//
//  VCFNetProductDownloaderDelegate.h
//  VariableSDK
//
//  Created by Wade Gasior on 5/16/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol VCFProductDownloaderDelegate <NSObject>

- (void)productDownloaderDidUpdateProgress:(float)progress;
- (void)productDownloaderDidComplete;
- (void)productDownloaderDidFailWithError:(NSError *)error;

@end

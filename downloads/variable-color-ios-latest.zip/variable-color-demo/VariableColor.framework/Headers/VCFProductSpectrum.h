//
//  VCFProductSpectrum.h
//  VariableColor
//
//  Created by Andrew T on 9/13/18.
//  Copyright © 2018 Variable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VCFSpectralPoint.h"

@interface VCFProductSpectrum : NSObject

@property (readonly, nonnull) NSArray<NSNumber*> *curve;
@property (readonly) NSUInteger start;
@property (readonly) NSUInteger step;
@property (readonly, nonnull) NSString *batch;
@property (readonly, nonnull) NSString *model;

-(NSArray<VCFSpectralPoint*>*) spectralCurve;


@end
